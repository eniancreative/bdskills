# Animation in the Dark | Café Text Animation | @keyframers 3.25.3

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/RwKoMmb](https://codepen.io/team/keyframers/pen/RwKoMmb).

David Khourshid & Stephen Shaw celebrate 10,000 Subscribers in this fun season finale, live coding designs & layouts IN THE DARK, without seeing the results until the final reveals! (No peaking!)

💡 Inspiration: https://dribbble.com/shots/15379368-Quick-Animation-Experiment
🎥  Video: https://youtu.be/mBY62jtbMYM
